<#if package?? && package != "">
package ${package};

</#if>
/**
 *
 * @author ${user}
 */
public class ${name}
{

}
